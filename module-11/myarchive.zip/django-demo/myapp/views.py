from django.shortcuts import render, HttpResponse

def home(request):
    return HttpResponse("Carpenter says Hello! :D")